const salarioMinimo = parseFloat(1212.00)

var incluirCliente = document.querySelector("#incluirCliente")
incluirCliente.addEventListener("click", function(event) {
    event.preventDefault()

    let form = document.querySelector("#form-inclui")

    let cpf = form.cpf.value
    let nome = form.nome.value
    let dataNascimento = form.dataNascimento.value
    let idade = calculaIdade(dataNascimento)
    let renda = form.renda.value   
    let justificativa = verificaRenda(renda) 
    

    let clienteTr = document.createElement("tr")

    clienteTr.className += "cliente "

    let rendaFloat = parseFloat(renda)    
    if (rendaFloat < salarioMinimo) {
        clienteTr.className += "cliente-invalido "
    }

    let cpfTd = document.createElement("td")
    let nomeTd = document.createElement("td")
    let dataNascimentoTd = document.createElement("td")
    let idadeTd = document.createElement("td")
    let rendaTd = document.createElement("td")
    let justificativaTd = document.createElement("td")

    cpfTd.className += "info-cpf"
    nomeTd.className += "info-nomeCliente"
    dataNascimentoTd.className += "info-dataNascimento"
    idadeTd.className += "info-idade"
    rendaTd.className += "info-renda"
    justificativaTd.className += "info-justificativa"

    cpfTd.textContent = cpf
    nomeTd.textContent = nome
    dataNascimentoTd.textContent = converteFormatoData(dataNascimento)
    idadeTd.textContent = idade
    rendaTd.textContent = ajustaRenda(renda)
    justificativaTd.textContent = justificativa

    clienteTr.appendChild(cpfTd)
    clienteTr.appendChild(nomeTd)
    clienteTr.appendChild(dataNascimentoTd)
    clienteTr.appendChild(idadeTd)
    clienteTr.appendChild(rendaTd)
    clienteTr.appendChild(justificativaTd)

    let tabelaClientes = document.querySelector("#tabela-clientes")

    tabelaClientes.appendChild(clienteTr)
    
    somarAsRendas()
    
    form.reset()
});




function converteFormatoData(dataNascimento){
    let dia = dataNascimento.substring(8, 10)
    let mes = dataNascimento.substring(5, 7)
    let ano = dataNascimento.substring(0, 4)
    let dataConvertida = dia + "/" + mes + "/" + ano
    return dataConvertida
}


function calculaIdade(dataNascimento){
    //Convertando data de Hoje e data de Nascimento em milesegundos
    const hoje = new Date() // Data de hoje
    const nascimento = new Date(dataNascimento) // Outra data no passado

    // Cálculo de Idade em Anos utilizando MILISEGUNDOS
    const diferencaMilisegundos = Math.abs(hoje.getTime() - nascimento.getTime()) //Subtrai uma data pela outra    
    const idade = Math.ceil(diferencaMilisegundos / (1000 * 60 * 60 * 24 * 365)) // Divide o total pelo total de milisegundos correspondentes a 1 ano.

    //OU AINDA, cálculo de Idade utilizando meses e anos
    let diferencaMeses = ajustaMesAno(hoje) - ajustaMesAno(nascimento)
    let idadeEmAnos = Math.floor(diferencaMeses / 12)
    let idadeEmMeses = diferencaMeses % 12
    let idadeComAnoseMeses = `${idadeEmAnos} anos e ${idadeEmMeses} meses`

    return idadeComAnoseMeses
}


function ajustaMesAno(d) {
    return d.getFullYear() * 12 + d.getMonth() + 1
}

function ajustaRenda(renda){
    let rendaConvertida = parseFloat(renda).toLocaleString('pt-br',{style: 'decimal',minimumFractionDigits:2})
    return rendaConvertida
}



function somarAsRendas(){
    let clientes = document.querySelectorAll(".cliente")
    let somaFloat = 0
    console.log('clientes:',clientes)
    console.log('somaFloat:',somaFloat)

    for (var i = 0; i < clientes.length; i++) {
        let cliente = clientes[i]
        let tdRenda = cliente.querySelector(".info-renda")
        let rendaString = tdRenda.textContent
        let rendaFloat = parseFloat(rendaString.toString().replace(/\./g, '').replace(',','.'))
        somaFloat = somaFloat + rendaFloat
        console.log('cliente:',cliente)
        console.log('tdRenda:',tdRenda)
        console.log('rendaString:',rendaString)
        console.log('rendaFloat:',rendaFloat)
    }  
    
    let somatorioRendas = document.querySelector("#somatorioRendas")
    let somaString = somaFloat.toLocaleString('pt-br',{style: 'decimal',minimumFractionDigits:2})
    somatorioRendas.innerHTML = somaString

}


function verificaRenda(renda) {
    let rendaFloat = parseFloat(renda)
    
    if (rendaFloat < salarioMinimo) {

        let justificativa = prompt("Valor informado da renda é inferior a um salário mínimo (R$ " + salarioMinimo.toLocaleString('pt-br',{style: 'decimal',minimumFractionDigits:2}) + "). Justifique:", "");
        if (justificativa != "") {
            alert("Obrigado por justificar!");
          }
        else {
            justificativa = "Faltou justificar!";
        };     

        return justificativa;
                
    } else {
        return ""
    }   
}



var tabelaClientes = document.querySelector("#tabela-clientes");

tabelaClientes.addEventListener("dblclick", function(event) {
    event.target.parentNode.classList.add("fadeOut");
    setTimeout(function() {
        event.target.parentNode.remove();
    }, 700);

});




