var botaoAdicionar = document.querySelector("#buscar-cliente");
botaoAdicionar.addEventListener("click", function(){

    var xhr = new XMLHttpRequest();

    xhr.open("GET", "http://www.ksamochvalov.com/academia/listarClientes.php?matricula=F3295813");

    xhr.addEventListener("load", function(){
        var erroAjax = document.querySelector("#erro-ajax");
        if(xhr.status === 200){
            erroAjax.classList.add("invisivel");
            var resposta = xhr.responseText;
            
            var clientes = JSON.parse(resposta);
            
    
            clientes.forEach(function(cliente){

                for(var x = 0; x < clientes.length; x++){
                    var data = clientes[x].data_nascimento;
                    
                        let dia = data.substring(8, 10)
                        let mes = data.substring(5, 7)
                        let ano = data.substring(0, 4)
                        let dataConvertida = dia + "/" + mes + "/" + ano
                        
                        data.querySelector(".info-data_nascimento").innerText = dataConvertida;
                }
                
                adicionaClienteNaTabela(cliente);
            });
        }else{
            console.log(xhr.status);
            console.log(xhr.responseText);
           
            erroAjax.classList.remove("invisivel");

        } 
    });
    xhr.send();
})