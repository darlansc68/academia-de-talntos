// Constante global que possui o valor salário mínimo
const salarioMinimo = parseFloat(1212.00)


// Constante global que indica quantidade total de caractes do CPF somando pontos e traço
const qtdCharCPF = 14;


// Constante global que indica Matricula do utilizador das APIs
const matricula = "F1694355"


// Array global que armazenará os dados dos clientes
let justificativas = []

// Constante global Formulário da Página
const form = document.querySelector("#form-inclui")

// Constante global com html do input justificar
const justificar_input = "<input type='text' placeholder='Justifique'>"